<hr>
<div class="container mt-4 py-5">

<footer class="page-footer center-on-small-only stylish-color-dark">
  <div class="container">
    <div class="row">
      <div class="col-md-4 col-xs-12">
          <ul class="un-order-list">

              <li><a href="#!">Udemy for Business</a></li>
              <li><a href="#!">Become an Instructor</a></li>
              <li><a href="#!">Mobile Apps</a></li>
          </ul>
      </div>
      <div class="col-md-4 col-xs-12">
          <ul class="un-order-list">
            <li><a href="#!">About Us</a></li>
            <li><a href="#!">Careers</a></li>
            <li><a href="#!">Blog</a></li>

          </ul>
      </div>
      <div class="col-md-4 col-xs-12">
              <ul class="un-order-list">
                <li><a href="#!">Topics</a></li>
                <li><a href="#!">Support</a></li>
                <li><a href="#!">Affiliate</a></li>
              </ul>
          </div>
    </div>
  </div>
</footer>

</div>
<footer class="py-4 footer-bg">
<div class="container">
<p class="m-0 text-center text-black">Copyright &copy; Udemy.com <?=date("Y")?></p>
</div>
</footer>
<script src="assets/public/vendor/jquery/jquery.min.js"></script>
<script src="assets/public/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/public/vendor/jquery/main.js"></script>
</body>
</html>
