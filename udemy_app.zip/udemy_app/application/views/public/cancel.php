<div class="title-background">
  <div class="container">
    <div class="py-5 mt-4">
      <h3>Dear Member</h3>
    </div>
  </div>
</div>
<div class="container">
  <div class="row">
    <div class="col-lg-12 mt-4">
      <h3 class="lead content">We are sorry! Your last transaction was cancelled. Please Try again</h3>
    </div>
  </div>
</div>
