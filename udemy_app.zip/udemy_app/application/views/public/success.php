<div class="title-background">
  <div class="container">
    <div class="py-5 mt-4">
      <h3>Dear Member</h3>
    </div>

  </div>

</div>
<div class="container">
  <div class="row">
    <div class="col-lg-12 mt-4">
      <h3 class="lead content">Your payment was successful, thank you for purchase.</h3>
    </div>
  </div>
</div>
